const searchInput = document.getElementById("searchInput");
const locationFilter = document.getElementById("locationFilter");
const searchButton = document.getElementById("searchButton");
const categoryButtons = [...document.querySelectorAll("[data-category]")];
const listingGrid = document.getElementById("listingGrid");
const resultCount = document.getElementById("resultCount");
const emptyState = document.getElementById("emptyState");
const sortSelect = document.getElementById("sortSelect");
let selectedCategory = "All";

function filterListings() {
  const query = searchInput.value.trim().toLowerCase();
  const location = locationFilter.value;
  const cards = [...listingGrid.querySelectorAll(".listing-card")];
  let visible = [];

  cards.forEach(card => {
    const categoryMatch = selectedCategory === "All" || card.dataset.category === selectedCategory;
    const textMatch = `${card.dataset.title} ${card.textContent}`.toLowerCase().includes(query);
    const locationMatch = !location || card.dataset.location === location;
    const show = categoryMatch && textMatch && locationMatch;
    card.hidden = !show;
    if (show) visible.push(card);
  });

  if (sortSelect.value === "low") visible.sort((a,b) => Number(a.dataset.price)-Number(b.dataset.price));
  if (sortSelect.value === "high") visible.sort((a,b) => Number(b.dataset.price)-Number(a.dataset.price));
  visible.forEach(card => listingGrid.appendChild(card));

  resultCount.textContent = `${visible.length} listing${visible.length === 1 ? "" : "s"}`;
  emptyState.hidden = visible.length !== 0;
}

function clearFilters() {
  searchInput.value = "";
  locationFilter.value = "";
  selectedCategory = "All";
  sortSelect.value = "featured";
  categoryButtons.forEach(button => button.classList.toggle("active", button.dataset.category === "All"));
  filterListings();
}

searchInput.addEventListener("input", filterListings);
locationFilter.addEventListener("change", filterListings);
searchButton.addEventListener("click", () => {
  filterListings();
  document.getElementById("listings").scrollIntoView({behavior:"smooth"});
});
sortSelect.addEventListener("change", filterListings);
document.getElementById("clearFilters").addEventListener("click", clearFilters);
document.getElementById("emptyClear").addEventListener("click", clearFilters);

categoryButtons.forEach(button => button.addEventListener("click", () => {
  selectedCategory = button.dataset.category;
  categoryButtons.forEach(item => item.classList.toggle("active", item === button));
  filterListings();
  document.getElementById("listings").scrollIntoView({behavior:"smooth", block:"start"});
}));

document.querySelectorAll(".favorite").forEach(button => button.addEventListener("click", () => {
  button.classList.toggle("saved");
  button.textContent = button.classList.contains("saved") ? "♥" : "♡";
  button.setAttribute("aria-pressed", button.classList.contains("saved") ? "true" : "false");
}));

const postDialog = document.getElementById("postDialog");
const detailsDialog = document.getElementById("detailsDialog");
document.querySelectorAll(".post-open").forEach(button => button.addEventListener("click", () => postDialog.showModal()));
document.querySelectorAll("[data-close]").forEach(button => button.addEventListener("click", () => document.getElementById(button.dataset.close).close()));

document.querySelectorAll(".details-button").forEach(button => button.addEventListener("click", () => {
  document.getElementById("detailTitle").textContent = button.dataset.title;
  document.getElementById("detailPrice").textContent = button.dataset.price;
  document.getElementById("detailDescription").textContent = button.dataset.description;
  document.getElementById("detailLocation").textContent = `⌖ ${button.dataset.location} · ${button.dataset.category}`;
  detailsDialog.showModal();
}));

document.getElementById("postForm").addEventListener("submit", event => {
  event.preventDefault();
  const form = event.currentTarget;
  const data = new FormData(form);
  const title = String(data.get("title")).trim();
  const category = String(data.get("category"));
  const price = Number(data.get("price"));
  const location = String(data.get("location")).trim();
  const description = String(data.get("description")).trim();

  if (!title || !location || !description || !Number.isFinite(price) || price < 0) return;

  const card = document.createElement("article");
  card.className = "listing-card";
  card.dataset.category = category;
  card.dataset.location = location;
  card.dataset.price = String(price);
  card.dataset.title = title;
  const image = document.createElement("div");
  image.className = "listing-image image-camera";
  const emoji = document.createElement("div");
  emoji.className = "product-emoji";
  emoji.textContent = "📦";
  image.appendChild(emoji);
  const info = document.createElement("div");
  info.className = "listing-info";
  const meta = document.createElement("div");
  meta.className = "listing-meta";
  const cat = document.createElement("span");
  cat.textContent = category === "Home" ? "Home & living" : category;
  const loc = document.createElement("span");
  loc.textContent = location;
  meta.append(cat, loc);
  const heading = document.createElement("h3");
  heading.textContent = title;
  const desc = document.createElement("p");
  desc.className = "listing-description";
  desc.textContent = description;
  const bottom = document.createElement("div");
  bottom.className = "listing-bottom";
  const priceEl = document.createElement("strong");
  priceEl.textContent = "₦" + price.toLocaleString("en-NG");
  const detail = document.createElement("button");
  detail.className = "details-button";
  detail.type = "button";
  detail.textContent = "View details ↗";
  detail.dataset.title = title;
  detail.dataset.price = priceEl.textContent;
  detail.dataset.description = description;
  detail.dataset.location = location;
  detail.dataset.category = category;
  detail.addEventListener("click", () => {
    document.getElementById("detailTitle").textContent = title;
    document.getElementById("detailPrice").textContent = priceEl.textContent;
    document.getElementById("detailDescription").textContent = description;
    document.getElementById("detailLocation").textContent = `⌖ ${location} · ${category}`;
    detailsDialog.showModal();
  });
  bottom.append(priceEl, detail);
  info.append(meta, heading, desc, bottom);
  card.append(image, info);
  listingGrid.prepend(card);

  // Keep the demo listing available after a page refresh in this browser.
  const saved = JSON.parse(localStorage.getItem("adsworld-demo-listings") || "[]");
  saved.unshift({title, category, price, location, description});
  localStorage.setItem("adsworld-demo-listings", JSON.stringify(saved.slice(0, 30)));

  document.getElementById("formStatus").textContent = "Listing added to this page. It is only visible in this browser.";
  form.reset();
  filterListings();
  setTimeout(() => {
    postDialog.close();
    document.getElementById("formStatus").textContent = "";
    document.getElementById("listings").scrollIntoView({behavior:"smooth"});
  }, 1200);
});

document.getElementById("year").textContent = new Date().getFullYear();
filterListings();
