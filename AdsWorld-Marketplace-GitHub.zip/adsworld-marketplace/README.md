# AdsWorld Marketplace

A responsive static marketplace template made with HTML, CSS, and vanilla JavaScript. It can be hosted on GitHub Pages.

## Files
- `index.html` — page structure and sample listings
- `style.css` — responsive visual design
- `script.js` — search, category filters, sorting, favorites, listing details, and demo post-ad form

## Publish on GitHub Pages
1. Create a public repository on GitHub.
2. Upload all three website files (`index.html`, `style.css`, `script.js`) to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Choose branch `main` and folder `/ (root)`, then save.
6. Wait for the deployment and open the URL shown in the Pages settings.

Official guide: https://docs.github.com/en/pages/quickstart

## Before launching publicly
- Replace the sample listings and emoji illustrations with real, authorized listing content and images.
- Configure real seller contact links.
- The included post-ad form is a front-end demo: it saves data in the visitor's browser only. To receive and publish listings for all visitors, connect a backend/database and add moderation and spam protection.
- Do not collect passwords or payment details in this static demo. Real accounts and payments need secure server-side services.
- Add your privacy policy, terms, contact information, and marketplace safety guidance.
